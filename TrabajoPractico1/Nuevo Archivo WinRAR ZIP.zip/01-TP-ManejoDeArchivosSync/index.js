const leerArchivoComoString = require('./src/utils/fileUtils')

// leo los 4 archivos a memoria
console.log(leerArchivoComoString("10NumerosOrdenadosEntre1y50(setA).in"));
// preparo los 4 arrays a partir de los archivo leidos

// combino los primeros dos arrays

// combino los cuatro arrays
